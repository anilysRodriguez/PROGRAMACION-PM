var resultados = 0;
function preguntaI(){
    var pregunta1 = document.getElementById("pregunta1").value;
    switch(pregunta1){
    case "3":
        resultados++
        break;
    }
}
function preguntaII(){
    var pregunta2 = document.getElementById("pregunta2").value;
    switch(pregunta2){
    case "4":
        resultados++
        break;
    }
}
function preguntaIII(){
    var pregunta3 = document.getElementById("pregunta3").value;
    switch(pregunta3){
    case "1":
        resultados++
        break;
    }
}
function preguntaIV(){
    var pregunta4 = document.getElementById("pregunta4").value;
    switch(pregunta4){
    case "1":
        resultados++
        break;
    }
}
function preguntaV(){
    var pregunta5 = document.getElementById("pregunta5").value;
    switch(pregunta5){
    case "4":
        resultados++
        break;
    }
}
function preguntaVI(){
    var pregunta6 = document.getElementById("pregunta6").value;
    switch(pregunta6){
    case "3":
        resultados++
        break;
    }
}
function preguntaVII(){
    var pregunta7 = document.getElementById("pregunta7").value;
    switch(pregunta7){
    case "6":
        resultados++
        break;
    }
}
function preguntaVIII(){
    var pregunta8 = document.getElementById("pregunta8").value;
    switch(pregunta8){
    case "2":
        resultados++
        alert("puntaje= "+ resultados + "/8");

        break;
    }
}


