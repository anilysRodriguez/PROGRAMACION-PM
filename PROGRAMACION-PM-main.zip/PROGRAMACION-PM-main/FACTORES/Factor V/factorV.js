var puntos = 0;
function pregunta1() {
    var error1 = document.getElementById("no1");
    var error2 = document.getElementById("no2");
    var error3 = document.getElementById("no3");
    var quest1 = document.getElementById("Grueso");
    var answe1 = document.getElementById("gordo");
    if (quest1 = answe1) {
        answe1.style.backgroundColor="  antiquewhite";
        answe1.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
        puntos++;
} else {}
}
function error1() {
    var error1 = document.getElementById("no1");
    var error2 = document.getElementById("no2");
    var error3 = document.getElementById("no3");
    var answe1 = document.getElementById("gordo");
    error1.style.backgroundColor=" antiquewhite";
    answe1.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error2() {
    var error1 = document.getElementById("no1");
    var error2 = document.getElementById("no2");
    var error3 = document.getElementById("no3");
    var answe1 = document.getElementById("gordo");
    error2.style.backgroundColor=" antiquewhite";
    answe1.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error3() {
    var error1 = document.getElementById("no1");
    var error2 = document.getElementById("no2");
    var error3 = document.getElementById("no3");
    var answe1 = document.getElementById("gordo");
    error3.style.backgroundColor=" antiquewhite";
    answe1.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta2() {
    var quest2 = document.getElementById("Anciano"); 
    var answe2 = document.getElementById("viejo");
    var error1 = document.getElementById("no4");
    var error2 = document.getElementById("no5");
    var error3 = document.getElementById("no6");
    if (quest2 = answe2) {
    answe2.style.backgroundColor="  antiquewhite";
    answe2.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
    puntos++;
} else {}
}
function error4() {
    var error1 = document.getElementById("no4");
    var error2 = document.getElementById("no5");
    var error3 = document.getElementById("no6");
    var answe2 = document.getElementById("viejo");
    error1.style.backgroundColor=" antiquewhite";
    answe2.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 
function error5() {
    var error1 = document.getElementById("no4");
    var error2 = document.getElementById("no5");
    var error3 = document.getElementById("no6");
    var answe2 = document.getElementById("viejo");
    error2.style.backgroundColor=" antiquewhite";
    answe2.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error6() {
    var error1 = document.getElementById("no4");
    var error2 = document.getElementById("no5");
    var error3 = document.getElementById("no6");
    var answe2 = document.getElementById("viejo");
    error3.style.backgroundColor=" antiquewhite";
    answe2.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 



function pregunta3() {
    var quest3 = document.getElementById("Bello");
    var answe3 = document.getElementById("hermoso");
    var error1 = document.getElementById("no7");
    var error2 = document.getElementById("no8");
    var error3 = document.getElementById("no9");
    if (quest3 = answe3) {
        answe3.style.backgroundColor="  antiquewhite";
        answe3.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error7() {
    var error1 = document.getElementById("no7");
    var error2 = document.getElementById("no8");
    var error3 = document.getElementById("no9");
    var answe3 = document.getElementById("hermoso");
    error1.style.backgroundColor=" antiquewhite";
    answe3.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error8() {
    var error1 = document.getElementById("no7");
    var error2 = document.getElementById("no8");
    var error3 = document.getElementById("no9");
    var answe3 = document.getElementById("hermoso");
    error2.style.backgroundColor=" antiquewhite";
    answe3.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 
function error9() {
    var error1 = document.getElementById("no7");
    var error2 = document.getElementById("no8");
    var error3 = document.getElementById("no9");
    var answe3 = document.getElementById("hermoso");
    error3.style.backgroundColor=" antiquewhite";
    answe3.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 



function pregunta4() {
    var error1 = document.getElementById("no10");
    var error2 = document.getElementById("no11");
    var error3 = document.getElementById("no12");
    var quest4 = document.getElementById("Facil");
    var answe4 = document.getElementById("sencillo");
    if (quest4 = answe4) {
        answe4.style.backgroundColor="  antiquewhite";
        answe4.disabled=true;
        error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
    puntos++;
} else {}
}
function error10() {
    var error1 = document.getElementById("no10");
    var error2 = document.getElementById("no11");
    var error3 = document.getElementById("no12");
    var answe4 = document.getElementById("sencillo");
    error1.style.backgroundColor=" antiquewhite";
    answe4.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error11() {
    var error1 = document.getElementById("no10");
    var error2 = document.getElementById("no11");
    var error3 = document.getElementById("no12");
    var answe4 = document.getElementById("sencillo");
    error2.style.backgroundColor=" antiquewhite";
    answe4.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error12() {
    var error1 = document.getElementById("no10");
    var error2 = document.getElementById("no11");
    var error3 = document.getElementById("no12");
    var answe4 = document.getElementById("sencillo");
    error3.style.backgroundColor=" antiquewhite";
    answe4.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta5() {
    var error1 = document.getElementById("no13");
    var error2 = document.getElementById("no14");
    var error3 = document.getElementById("no15");
    var quest5 = document.getElementById("Batalla");
    var answe5 = document.getElementById("guerra");
    if (quest5 = answe5) {
        answe5.style.backgroundColor="  antiquewhite";
        answe5.disabled=true;
        answe5.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
    puntos++;
} else {}
}
function error13() {
    var error1 = document.getElementById("no13");
    var error2 = document.getElementById("no14");
    var error3 = document.getElementById("no15");
    var answe5 = document.getElementById("guerra");
    error1.style.backgroundColor=" antiquewhite";
    answe5.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error14() {
    var error1 = document.getElementById("no13");
    var error2 = document.getElementById("no14");
    var error3 = document.getElementById("no15");
    var answe5 = document.getElementById("guerra");
    error2.style.backgroundColor=" antiquewhite";
    answe5.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error15() {
    var error1 = document.getElementById("no13");
    var error2 = document.getElementById("no14");
    var error3 = document.getElementById("no15");
    var answe5 = document.getElementById("guerra");
    error3.style.backgroundColor=" antiquewhite";
    answe5.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta6() {
    var error1 = document.getElementById("no16");
    var error2 = document.getElementById("no17");
    var error3 = document.getElementById("no18");
    var quest6 = document.getElementById("Apto");
    var answe6 = document.getElementById("habil");
    if (quest6 = answe6) {
        answe6.style.backgroundColor="  antiquewhite";
        answe6.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}   
function error16() {
    var error1 = document.getElementById("no16");
    var error2 = document.getElementById("no17");
    var error3 = document.getElementById("no18");
    var answe6 = document.getElementById("habil");
    error1.style.backgroundColor=" antiquewhite";
    answe6.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error17() {
    var error1 = document.getElementById("no16");
    var error2 = document.getElementById("no17");
    var error3 = document.getElementById("no18");
    var answe6 = document.getElementById("habil");
    error2.style.backgroundColor=" antiquewhite";
    answe6.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error18() {
    var error1 = document.getElementById("no16");
    var error2 = document.getElementById("no17");
    var error3 = document.getElementById("no18");
    var answe6 = document.getElementById("habil");
    error3.style.backgroundColor=" antiquewhite";
    answe6.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta7() {
    var error1 = document.getElementById("no19");
    var error2 = document.getElementById("no20");
    var error3 = document.getElementById("no21");
    var quest7 = document.getElementById("Vivir");
    var answe7 = document.getElementById("habitar");
    if (quest7 = answe7) {
        answe7.style.backgroundColor="  antiquewhite";
        answe7.disabled=true;
        error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
    puntos++;
} else {}  
}
function error19() {
    var error1 = document.getElementById("no19");
    var error2 = document.getElementById("no20");
    var error3 = document.getElementById("no21");
    var answe7 = document.getElementById("habitar");
    error1.style.backgroundColor=" antiquewhite";
    answe7.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error20() {
    var error1 = document.getElementById("no19");
    var error2 = document.getElementById("no20");
    var error3 = document.getElementById("no21");
    var answe7 = document.getElementById("habitar");
    error2.style.backgroundColor=" antiquewhite";
    answe7.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error21() {
    var error1 = document.getElementById("no19");
    var error2 = document.getElementById("no20");
    var error3 = document.getElementById("no21");
    var answe7 = document.getElementById("habitar");
    error3.style.backgroundColor=" antiquewhite";
    answe7.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


function pregunta8() {
    var error1 = document.getElementById("no22");
    var error2 = document.getElementById("no23");
    var error3 = document.getElementById("no24");
    var quest8 = document.getElementById("Soberania");
    var answe8 = document.getElementById("monarquia");
    if (quest8 = answe8) {
        answe8.style.backgroundColor="  antiquewhite";
        answe8.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error22() {
    var error1 = document.getElementById("no22");
    var error2 = document.getElementById("no23");
    var error3 = document.getElementById("no24");
    var answe8 = document.getElementById("monarquia");
    error1.style.backgroundColor=" antiquewhite";
    answe8.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error23() {
    var error1 = document.getElementById("no22");
    var error2 = document.getElementById("no23");
    var error3 = document.getElementById("no24");
    var answe8 = document.getElementById("monarquia");
    error2.style.backgroundColor=" antiquewhite";
    answe8.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error24() {
    var error1 = document.getElementById("no22");
    var error2 = document.getElementById("no23");
    var error3 = document.getElementById("no24");
    var answe8 = document.getElementById("monarquia");
    error3.style.backgroundColor=" antiquewhite";
    answe8.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta9() {
    var error1 = document.getElementById("no25");
    var error2 = document.getElementById("no26");
    var error3 = document.getElementById("no27");
    var quest9 = document.getElementById("Valiente");
    var answe9 = document.getElementById("aventurero");
    if (quest9 = answe9) {
        answe9.style.backgroundColor="  antiquewhite";
        answe9.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error25() {
    var error1 = document.getElementById("no25");
    var error2 = document.getElementById("no26");
    var error3 = document.getElementById("no27");
    var answe9 = document.getElementById("aventurero");
    error1.style.backgroundColor=" antiquewhite";
    answe9.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error26() {
    var error1 = document.getElementById("no25");
    var error2 = document.getElementById("no26");
    var error3 = document.getElementById("no27");
    var answe9 = document.getElementById("aventurero");
    error2.style.backgroundColor=" antiquewhite";
    answe9.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error27() {
    var error1 = document.getElementById("no25");
    var error2 = document.getElementById("no26");
    var error3 = document.getElementById("no27");
    var answe9 = document.getElementById("aventurero");
    error3.style.backgroundColor=" antiquewhite";
    answe9.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta10() {
    var error1 = document.getElementById("no28");
    var error2 = document.getElementById("no29");
    var error3 = document.getElementById("no30")
    var quest10 = document.getElementById("Mentira");
    var answe10 = document.getElementById("embuste");
    if (quest10 = answe10) {
        answe10.style.backgroundColor="  antiquewhite"; 
        answe10.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
       puntos++;
} else {}
} 
function error28() {
    var error1 = document.getElementById("no28");
    var error2 = document.getElementById("no29");
    var error3 = document.getElementById("no30");
    var answe10 = document.getElementById("embuste");
    error1.style.backgroundColor=" antiquewhite";
    answe10.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error29() {
    var error1 = document.getElementById("no28");
    var error2 = document.getElementById("no29");
    var error3 = document.getElementById("no30");
    var answe10 = document.getElementById("embuste");
    error2.style.backgroundColor=" antiquewhite";
    answe10.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error30() {
    var error1 = document.getElementById("no28");
    var error2 = document.getElementById("no29");
    var error3 = document.getElementById("no30");
    var answe10 = document.getElementById("embuste");
    error3.style.backgroundColor=" antiquewhite";
    answe10.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


function pregunta11() {
    var error1 = document.getElementById("no31");
    var error2 = document.getElementById("no32");
    var error3 = document.getElementById("no33");
    var quest11 = document.getElementById("Crear");
    var answe11 = document.getElementById("inventar");
    if (quest11 = answe11) {
        answe11.style.backgroundColor="  antiquewhite"; 
        answe11.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error31() {
    var error1 = document.getElementById("no31");
    var error2 = document.getElementById("no32");
    var error3 = document.getElementById("no33");
    var answe11 = document.getElementById("inventar");
    error1.style.backgroundColor=" antiquewhite";
    answe11.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error32() {
    var error1 = document.getElementById("no31");
    var error2 = document.getElementById("no32");
    var error3 = document.getElementById("no33");
    var answe11 = document.getElementById("inventar");
    error2.style.backgroundColor=" antiquewhite";
    answe11.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error33() {
    var error1 = document.getElementById("no31");
    var error2 = document.getElementById("no32");
    var error3 = document.getElementById("no33");
    var answe11 = document.getElementById("inventar");
    error3.style.backgroundColor=" antiquewhite";
    answe11.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta12() {
    var error1 = document.getElementById("no34");
    var error2 = document.getElementById("no35");
    var error3 = document.getElementById("no36");
    var quest12 = document.getElementById("Cama");
    var answe12 = document.getElementById("lecho");
    if (quest12 = answe12) { 
        answe12.style.backgroundColor="  antiquewhite";
        answe12.disabled=true;  
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {}
}   
function error34() {
    var error1 = document.getElementById("no34");
    var error2 = document.getElementById("no35");
    var error3 = document.getElementById("no36");
    var answe12 = document.getElementById("lecho");
    error1.style.backgroundColor=" antiquewhite";
    answe12.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error35() {
    var error1 = document.getElementById("no34");
    var error2 = document.getElementById("no35");
    var error3 = document.getElementById("no36");
    var answe12 = document.getElementById("lecho");
    error2.style.backgroundColor=" antiquewhite";
    answe12.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error36() {
    var error1 = document.getElementById("no34");
    var error2 = document.getElementById("no35");
    var error3 = document.getElementById("no36");
    var answe12 = document.getElementById("lecho");
    error3.style.backgroundColor=" antiquewhite";
    answe12.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta13() {
    var error1 = document.getElementById("no37");
    var error2 = document.getElementById("no38");
    var error3 = document.getElementById("no39");
    var quest13 = document.getElementById("Comprar");
    var answe13 = document.getElementById("adquirir");
    if (quest13 = answe13) {
        answe13.style.backgroundColor="  antiquewhite"; 
        answe13.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error37() {
    var error1 = document.getElementById("no37");
    var error2 = document.getElementById("no38");
    var error3 = document.getElementById("no39");
    var answe13 = document.getElementById("adquirir");
    error1.style.backgroundColor=" antiquewhite";
    answe13.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error38() {
    var error1 = document.getElementById("no37");
    var error2 = document.getElementById("no38");
    var error3 = document.getElementById("no39");
    var answe13 = document.getElementById("adquirir");
    error2.style.backgroundColor=" antiquewhite";
    answe13.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error39() {
    var error1 = document.getElementById("no37");
    var error2 = document.getElementById("no38");
    var error3 = document.getElementById("no39");
    var answe13 = document.getElementById("adquirir");
    error3.style.backgroundColor=" antiquewhite";
    answe13.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


    
function pregunta14() {
    var error1 = document.getElementById("no40");
    var error2 = document.getElementById("no41");
    var error3 = document.getElementById("no42");
    var quest14 = document.getElementById("Necio");
    var answe14 = document.getElementById("bobo");
    if (quest14 = answe14) {
        answe14.style.backgroundColor="  antiquewhite";
        answe14.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error40() {
    var error1 = document.getElementById("no40");
    var error2 = document.getElementById("no41");
    var error3 = document.getElementById("no42");
    var answe14 = document.getElementById("bobo");
    error1.style.backgroundColor=" antiquewhite";
    answe14.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error41() {
    var error1 = document.getElementById("no40");
    var error2 = document.getElementById("no41");
    var error3 = document.getElementById("no42");
    var answe14 = document.getElementById("bobo");
    error2.style.backgroundColor=" antiquewhite";
    answe14.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error42() {
    var error1 = document.getElementById("no40");
    var error2 = document.getElementById("no41");
    var error3 = document.getElementById("no42");
    var answe14 = document.getElementById("bobo");
    error3.style.backgroundColor=" antiquewhite";
    answe14.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


    
function pregunta15() {
    var error1 = document.getElementById("no43");
    var error2 = document.getElementById("no44");
    var error3 = document.getElementById("no45");
    var quest15 = document.getElementById("Armonia");
    var answe15 = document.getElementById("calma");
    if (quest15 = answe15) {
        answe15.style.backgroundColor="  antiquewhite";
        answe15.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;  
    puntos++;
} else {}
}
function error43() {
    var error1 = document.getElementById("no43");
    var error2 = document.getElementById("no44");
    var error3 = document.getElementById("no45");
    var answe15 = document.getElementById("bobo");
    error1.style.backgroundColor=" antiquewhite";
    answe15.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error44() {
    var error1 = document.getElementById("no43");
    var error2 = document.getElementById("no44");
    var error3 = document.getElementById("no45");
    var answe15 = document.getElementById("bobo");
    error2.style.backgroundColor=" antiquewhite";
    answe15.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error45() {
    var error1 = document.getElementById("no43");
    var error2 = document.getElementById("no44");
    var error3 = document.getElementById("no45");
    var answe15 = document.getElementById("bobo");
    error3.style.backgroundColor=" antiquewhite";
    answe15.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


    
function pregunta16() {
    var error1 = document.getElementById("no46");
    var error2 = document.getElementById("no47");
    var error3 = document.getElementById("no48");
    var quest16 = document.getElementById("Insolencia");
    var answe16 = document.getElementById("arrogancia");
    if (quest16 = answe16) {
        answe16.style.backgroundColor="  antiquewhite";
        answe16.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {} 
}
function error46() {
    var error1 = document.getElementById("no46");
    var error2 = document.getElementById("no47");
    var error3 = document.getElementById("no48");
    var answe16 = document.getElementById("arrogancia");
    error1.style.backgroundColor=" antiquewhite";
    answe16.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error47() {
    var error1 = document.getElementById("no46");
    var error2 = document.getElementById("no47");
    var error3 = document.getElementById("no48");
    var answe16 = document.getElementById("arrogancia");
    error2.style.backgroundColor=" antiquewhite";
    answe16.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error48() {
    var error1 = document.getElementById("no46");
    var error2 = document.getElementById("no47");
    var error3 = document.getElementById("no48");
    var answe16 = document.getElementById("arrogancia");
    error3.style.backgroundColor=" antiquewhite";
    answe16.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta17() {
    var error1 = document.getElementById("no49");
    var error2 = document.getElementById("no50");
    var error3 = document.getElementById("no51");
    var quest17 = document.getElementById("Congelar");
    var answe17 = document.getElementById("frizar");
    if (quest17 = answe17) { 
        answe17.style.backgroundColor="  antiquewhite";
        answe17.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error49() {
    var error1 = document.getElementById("no49");
    var error2 = document.getElementById("no50");
    var error3 = document.getElementById("no51");
    var answe17 = document.getElementById("frizar");
    error1.style.backgroundColor=" antiquewhite";
    answe17.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error50() {
    var error1 = document.getElementById("no49");
    var error2 = document.getElementById("no50");
    var error3 = document.getElementById("no51");
    var answe17 = document.getElementById("frizar");
    error2.style.backgroundColor=" antiquewhite";
    answe17.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error51() {
    var error1 = document.getElementById("no49");
    var error2 = document.getElementById("no50");
    var error3 = document.getElementById("no51");
    var answe17 = document.getElementById("frizar");
    error3.style.backgroundColor=" antiquewhite";
    answe17.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta18() {
    var error1 = document.getElementById("no52");
    var error2 = document.getElementById("no53");
    var error3 = document.getElementById("no54");
    var quest18 = document.getElementById("Morir");
    var answe18 = document.getElementById("fallecer");
    if (quest18 = answe18) {
        answe18.style.backgroundColor="  antiquewhite"; 
        answe18.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
        puntos++;
} else {}
} 
function error52() {
    var error1 = document.getElementById("no52");
    var error2 = document.getElementById("no53");
    var error3 = document.getElementById("no54");
    var answe18 = document.getElementById("fallecer");
    error1.style.backgroundColor=" antiquewhite";
    answe18.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error53() {
    var error1 = document.getElementById("no52");
    var error2 = document.getElementById("no53");
    var error3 = document.getElementById("no54");
    var answe18 = document.getElementById("fallecer");
    error2.style.backgroundColor=" antiquewhite";
    answe18.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error54() {
    var error1 = document.getElementById("no52");
    var error2 = document.getElementById("no53");
    var error3 = document.getElementById("no54");
    var answe18 = document.getElementById("fallecer");
    error3.style.backgroundColor=" antiquewhite";
    answe18.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta19() {
    var error1 = document.getElementById("no55");
    var error2 = document.getElementById("no56");
    var error3 = document.getElementById("no57");
    var quest19 = document.getElementById("Generoso");
    var answe19 = document.getElementById("dadivoso");
    if (quest19 = answe19) {  
        answe19.style.backgroundColor="  antiquewhite";
        answe19.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error55() {
    var error1 = document.getElementById("no55");
    var error2 = document.getElementById("no56");
    var error3 = document.getElementById("no57");
    var answe19 = document.getElementById("dadivoso");
    error1.style.backgroundColor=" antiquewhite";
    answe19.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}  
function error56() {
    var error1 = document.getElementById("no55");
    var error2 = document.getElementById("no56");
    var error3 = document.getElementById("no57");
    var answe19 = document.getElementById("dadivoso");
    error2.style.backgroundColor=" antiquewhite";
    answe19.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error57() {
    var error1 = document.getElementById("no55");
    var error2 = document.getElementById("no56");
    var error3 = document.getElementById("no57");
    var answe19 = document.getElementById("dadivoso");
    error3.style.backgroundColor=" antiquewhite";
    answe19.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 



function pregunta20() {
    var error1 = document.getElementById("no58");
    var error2 = document.getElementById("no59");
    var error3 = document.getElementById("no60");
    var quest20 = document.getElementById("Delegacion");
    var answe20 = document.getElementById("junta");
    if (quest20 = answe20) { 
        answe20.style.backgroundColor="  antiquewhite"; 
        answe20.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error58() {
    var error1 = document.getElementById("no58");
    var error2 = document.getElementById("no59");
    var error3 = document.getElementById("no60");
    var answe20 = document.getElementById("junta");
    error1.style.backgroundColor=" antiquewhite";
    answe20.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error59() {
    var error1 = document.getElementById("no58");
    var error2 = document.getElementById("no59");
    var error3 = document.getElementById("no60");
    var answe20 = document.getElementById("junta");
    error2.style.backgroundColor=" antiquewhite";
    answe20.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error60() {
    var error1 = document.getElementById("no58");
    var error2 = document.getElementById("no59");
    var error3 = document.getElementById("no60");
    var answe20 = document.getElementById("junta");
    error3.style.backgroundColor=" antiquewhite";
    answe20.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta21() {
    var error1 = document.getElementById("no61");
    var error2 = document.getElementById("no62");
    var error3 = document.getElementById("no63");
    var quest21 = document.getElementById("Lanzar");
    var answe21 = document.getElementById("arrojar");
    if (quest21 = answe21) {
        answe21.style.backgroundColor="  antiquewhite";
        answe21.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error61() {
    var error1 = document.getElementById("no61");
    var error2 = document.getElementById("no62");
    var error3 = document.getElementById("no63");
    var answe21 = document.getElementById("arrojar");
    error1.style.backgroundColor=" antiquewhite";
    answe21.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error62() {
    var error1 = document.getElementById("no61");
    var error2 = document.getElementById("no62");
    var error3 = document.getElementById("no63");
    var answe21 = document.getElementById("arrojar");
    error2.style.backgroundColor=" antiquewhite";
    answe21.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error63() {
    var error1 = document.getElementById("no61");
    var error2 = document.getElementById("no62");
    var error3 = document.getElementById("no63");
    var answe21 = document.getElementById("arrojar");
    error3.style.backgroundColor=" antiquewhite";
    answe21.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta22() {
    var error1 = document.getElementById("no64");
    var error2 = document.getElementById("no65");
    var error3 = document.getElementById("no66");
    var quest22 = document.getElementById("Sabroso");
    var answe22 = document.getElementById("rico");
    if (quest22 = answe22) { 
        answe22.style.backgroundColor="  antiquewhite";
        answe22.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error64() {
    var error1 = document.getElementById("no64");
    var error2 = document.getElementById("no65");
    var error3 = document.getElementById("no66");
    var answe22 = document.getElementById("rico");
    error1.style.backgroundColor=" antiquewhite";
    answe22.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error65() {
    var error1 = document.getElementById("no64");
    var error2 = document.getElementById("no65");
    var error3 = document.getElementById("no66");
    var answe22 = document.getElementById("rico");
    error2.style.backgroundColor=" antiquewhite";
    answe22.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error66() {
    var error1 = document.getElementById("no64");
    var error2 = document.getElementById("no65");
    var error3 = document.getElementById("no66");
    var answe22 = document.getElementById("rico");
    error3.style.backgroundColor=" antiquewhite";
    answe22.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta23() {
    var error1 = document.getElementById("no67");
    var error2 = document.getElementById("no68");
    var error3 = document.getElementById("no69");
    var quest23 = document.getElementById("Conocer");
    var answe23 = document.getElementById("saber");
    if (quest23 = answe23) {
        answe23.style.backgroundColor="  antiquewhite";
        answe23.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error67() {
    var error1 = document.getElementById("no67");
    var error2 = document.getElementById("no68");
    var error3 = document.getElementById("no69");
    var answe23 = document.getElementById("saber");
    error1.style.backgroundColor=" antiquewhite";
    answe23.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error68() {
    var error1 = document.getElementById("no67");
    var error2 = document.getElementById("no68");
    var error3 = document.getElementById("no69");
    var answe23 = document.getElementById("saber");
    error2.style.backgroundColor=" antiquewhite";
    answe23.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error69() {
    var error1 = document.getElementById("no67");
    var error2 = document.getElementById("no68");
    var error3 = document.getElementById("no69");
    var answe23 = document.getElementById("saber");
    error3.style.backgroundColor=" antiquewhite";
    answe23.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta24() {
    var error1 = document.getElementById("no70");
    var error2 = document.getElementById("no71");
    var error3 = document.getElementById("no72");
    var quest24 = document.getElementById("Sufrir");
    var answe24 = document.getElementById("adolecer");
    if (quest24 = answe24) {
        answe24.style.backgroundColor="  antiquewhite";  
        answe24.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error70() {
    var error1 = document.getElementById("no70");
    var error2 = document.getElementById("no71");
    var error3 = document.getElementById("no72");
    var answe24 = document.getElementById("adolecer");
    error1.style.backgroundColor=" antiquewhite";
    answe24.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error71() {
    var error1 = document.getElementById("no70");
    var error2 = document.getElementById("no71");
    var error3 = document.getElementById("no72");
    var answe24 = document.getElementById("adolecer");
    error2.style.backgroundColor=" antiquewhite";
    answe24.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error72() {
    var error1 = document.getElementById("no70");
    var error2 = document.getElementById("no71");
    var error3 = document.getElementById("no72");
    var answe24 = document.getElementById("adolecer");
    error3.style.backgroundColor=" antiquewhite";
    answe24.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta25() {
    var error1 = document.getElementById("no73");
    var error2 = document.getElementById("no74");
    var error3 = document.getElementById("no75");
    var quest25 = document.getElementById("Querer");
    var answe25 = document.getElementById("pretender");
    if (quest25 = answe25) {
        answe25.style.backgroundColor="  antiquewhite"; 
        answe25.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {}
}
function error73() {
    var error1 = document.getElementById("no73");
    var error2 = document.getElementById("no74");
    var error3 = document.getElementById("no75");
    var answe25 = document.getElementById("pretender");
    error1.style.backgroundColor=" antiquewhite";
    answe25.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error74() {
    var error1 = document.getElementById("no73");
    var error2 = document.getElementById("no74");
    var error3 = document.getElementById("no75");
    var answe25 = document.getElementById("pretender");
    error2.style.backgroundColor=" antiquewhite";
    answe25.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error75() {
    var error1 = document.getElementById("no73");
    var error2 = document.getElementById("no74");
    var error3 = document.getElementById("no75");
    var answe25 = document.getElementById("pretender");
    error3.style.backgroundColor=" antiquewhite";
    answe25.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta26() {
    var error1 = document.getElementById("no76");
    var error2 = document.getElementById("no77");
    var error3 = document.getElementById("no78");
    var quest26 = document.getElementById("Tiniebla");
    var answe26 = document.getElementById("penumbra");
    if (quest26 = answe26) {
        answe26.style.backgroundColor="  antiquewhite"; 
        answe26.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {}
}
function error76() {
    var error1 = document.getElementById("no76");
    var error2 = document.getElementById("no77");
    var error3 = document.getElementById("no78");
    var answe26 = document.getElementById("penumbra");
    error1.style.backgroundColor=" antiquewhite";
    answe26.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 
function error77() {
    var error1 = document.getElementById("no76");
    var error2 = document.getElementById("no77");
    var error3 = document.getElementById("no78");
    var answe26 = document.getElementById("penumbra");
    error2.style.backgroundColor=" antiquewhite";
    answe26.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error78() {
    var error1 = document.getElementById("no76");
    var error2 = document.getElementById("no77");
    var error3 = document.getElementById("no78");
    var answe26 = document.getElementById("penumbra");
    error3.style.backgroundColor=" antiquewhite";
    answe26.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta27() {
    var error1 = document.getElementById("no79");
    var error2 = document.getElementById("no80");
    var error3 = document.getElementById("no81");
    var quest27 = document.getElementById("Momento");
    var answe27 = document.getElementById("instante");
    if (quest27 = answe27) {  
        answe27.style.backgroundColor="  antiquewhite"; 
        answe27.disabled=true; 
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {}
}
function error79() {
    var error1 = document.getElementById("no79");
    var error2 = document.getElementById("no80");
    var error3 = document.getElementById("no81");
    var answe27 = document.getElementById("instante");
    error1.style.backgroundColor=" antiquewhite";
    answe27.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error80() {
    var error1 = document.getElementById("no79");
    var error2 = document.getElementById("no80");
    var error3 = document.getElementById("no81");
    var answe27 = document.getElementById("instante");
    error2.style.backgroundColor=" antiquewhite";
    answe27.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error81() {
    var error1 = document.getElementById("no79");
    var error2 = document.getElementById("no80");
    var error3 = document.getElementById("no81");
    var answe27 = document.getElementById("instante");
    error3.style.backgroundColor=" antiquewhite";
    answe27.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 



function pregunta28() {
    var error1 = document.getElementById("no82");
    var error2 = document.getElementById("no83");
    var error3 = document.getElementById("no84");
    var quest28 = document.getElementById("Nota");
    var answe28 = document.getElementById("calificacion");
    if (quest28 = answe28) {
        answe28.style.backgroundColor="  antiquewhite";  
        answe28.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error82() {
    var error1 = document.getElementById("no82");
    var error2 = document.getElementById("no83");
    var error3 = document.getElementById("no84");
    var answe28 = document.getElementById("calificacion");
    error1.style.backgroundColor=" antiquewhite";
    answe28.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error83() {
    var error1 = document.getElementById("no82");
    var error2 = document.getElementById("no83");
    var error3 = document.getElementById("no84");
    var answe28 = document.getElementById("calificacion");
    error2.style.backgroundColor=" antiquewhite";
    answe28.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error84() {
    var error1 = document.getElementById("no82");
    var error2 = document.getElementById("no83");
    var error3 = document.getElementById("no84");
    var answe28 = document.getElementById("calificacion");
    error3.style.backgroundColor="antiquewhite";
    answe28.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta29() {
    var error1 = document.getElementById("no85");
    var error2 = document.getElementById("no86");
    var error3 = document.getElementById("no87");
    var quest29= document.getElementById("Saeta");
    var answe29= document.getElementById("flecha");
    if (quest29 = answe29) {
        answe29.style.backgroundColor="antiquewhite";  
        answe29.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {}
}
function error85() {
    var error1 = document.getElementById("no85");
    var error2 = document.getElementById("no86");
    var error3 = document.getElementById("no87");
    var answe29= document.getElementById("flecha");
    error1.style.backgroundColor="antiquewhite";
    answe29.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error86() {
    var error1 = document.getElementById("no85");
    var error2 = document.getElementById("no86");
    var error3 = document.getElementById("no87");
    var answe29= document.getElementById("flecha");
    error2.style.backgroundColor="antiquewhite";
    answe29.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 
function error87() {
    var error1 = document.getElementById("no85");
    var error2 = document.getElementById("no86");
    var error3 = document.getElementById("no87");
    var answe29= document.getElementById("flecha");
    error3.style.backgroundColor="antiquewhite";
    answe29.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 



function pregunta30() {
    var error1 = document.getElementById("no88");
    var error2 = document.getElementById("no89");
    var error3 = document.getElementById("no90");
    var quest30 = document.getElementById("Exponer");
    var answe30 = document.getElementById("expresar");
    if (quest30 = answe30) {
        answe30.style.backgroundColor="antiquewhite";  
        answe30.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {} 
}
function error88() {
    var error1 = document.getElementById("no88");
    var error2 = document.getElementById("no89");
    var error3 = document.getElementById("no90");
    var answe30 = document.getElementById("expresar");
    error1.style.backgroundColor="antiquewhite";
    answe30.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error89() {
    var error1 = document.getElementById("no88");
    var error2 = document.getElementById("no89");
    var error3 = document.getElementById("no90");
    var answe30 = document.getElementById("expresar");
    error2.style.backgroundColor="antiquewhite";
    answe30.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error90() {
    var error1 = document.getElementById("no88");
    var error2 = document.getElementById("no89");
    var error3 = document.getElementById("no90");
    var answe30 = document.getElementById("expresar");
    error3.style.backgroundColor="antiquewhite";
    answe30.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta31() {
    var error1 = document.getElementById("no91");
    var error2 = document.getElementById("no92");
    var error3 = document.getElementById("no93");
    var quest31 = document.getElementById("Retrato");
    var answe31 = document.getElementById("fotografia");
    if (quest31 = answe31) {
        answe31.style.backgroundColor="antiquewhite";
        answe31.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error91() {
    var error1 = document.getElementById("no91");
    var error2 = document.getElementById("no92");
    var error3 = document.getElementById("no93");
    var answe31 = document.getElementById("fotografia");
    error1.style.backgroundColor="antiquewhite";
    answe31.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error92() {
    var error1 = document.getElementById("no91");
    var error2 = document.getElementById("no92");
    var error3 = document.getElementById("no93");
    var answe31 = document.getElementById("fotografia");
    error2.style.backgroundColor="antiquewhite";
    answe31.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error93() {
    var error1 = document.getElementById("no91");
    var error2 = document.getElementById("no92");
    var error3 = document.getElementById("no93");
    var answe31 = document.getElementById("fotografia");
    error3.style.backgroundColor="antiquewhite";
    answe31.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}     



function pregunta32() {
    var error1 = document.getElementById("no94");
    var error2 = document.getElementById("no95");
    var error3 = document.getElementById("no96");
    var quest32 = document.getElementById("Detener");
    var answe32 = document.getElementById("parar");
    if (quest32 = answe32) {
        answe32.style.backgroundColor="antiquewhite";
        answe32.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error94() {
    var error1 = document.getElementById("no94");
    var error2 = document.getElementById("no95");
    var error3 = document.getElementById("no96");
    var answe32 = document.getElementById("parar");
    error1.style.backgroundColor="antiquewhite";
    answe32.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error95() {
    var error1 = document.getElementById("no94");
    var error2 = document.getElementById("no95");
    var error3 = document.getElementById("no96");
    var answe32 = document.getElementById("parar");
    error2.style.backgroundColor="antiquewhite";
    answe32.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error96() {
    var error1 = document.getElementById("no94");
    var error2 = document.getElementById("no95");
    var error3 = document.getElementById("no96");
    var answe32 = document.getElementById("parar");
    error3.style.backgroundColor="antiquewhite";
    answe32.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
} 



function pregunta33() {
    var error1 = document.getElementById("no97");
    var error2 = document.getElementById("no98");
    var error3 = document.getElementById("no99");
    var quest33 = document.getElementById("Añorar");
    var answe33 = document.getElementById("extrañar");
    if (quest33 = answe33) {
        answe33.style.backgroundColor="antiquewhite";  
        answe33.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error97() {
    var error1 = document.getElementById("no97");
    var error2 = document.getElementById("no98");
    var error3 = document.getElementById("no99");
    var answe33 = document.getElementById("extrañar");
    error1.style.backgroundColor="antiquewhite";
    answe33.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error98() {
    var error1 = document.getElementById("no97");
    var error2 = document.getElementById("no98");
    var error3 = document.getElementById("no99");
    var answe33 = document.getElementById("extrañar");
    error2.style.backgroundColor="antiquewhite";
    answe33.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error99() {
    var error1 = document.getElementById("no97");
    var error2 = document.getElementById("no98");
    var error3 = document.getElementById("no99");
    var answe33 = document.getElementById("extrañar");
    error3.style.backgroundColor="antiquewhite";
    answe33.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta34() {
    var error1 = document.getElementById("no100");
    var error2 = document.getElementById("no101");
    var error3 = document.getElementById("no102");
    var quest34 = document.getElementById("Fingir");
    var answe34 = document.getElementById("disimular");
    if (quest34 = answe34) {
        answe34.style.backgroundColor="antiquewhite";
        answe34.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;  
    puntos++;
} else {}
}
function error100() {
    var error1 = document.getElementById("no100");
    var error2 = document.getElementById("no101");
    var error3 = document.getElementById("no102");
    var answe34 = document.getElementById("disimular");
    error1.style.backgroundColor="antiquewhite";
    answe34.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error101() {
    var error1 = document.getElementById("no100");
    var error2 = document.getElementById("no101");
    var error3 = document.getElementById("no102");
    var answe34 = document.getElementById("disimular");
    error2.style.backgroundColor="antiquewhite";
    answe34.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error102() {
    var error1 = document.getElementById("no100");
    var error2 = document.getElementById("no101");
    var error3 = document.getElementById("no102");
    var answe34 = document.getElementById("disimular");
    error3.style.backgroundColor="antiquewhite";
    answe34.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta35() {
    var error1 = document.getElementById("no103");
    var error2 = document.getElementById("no104");
    var error3 = document.getElementById("no105");
    var quest35 = document.getElementById("Alumbrar");
    var answe35 = document.getElementById("iluminar");
    if (quest35 = answe35) {
        answe35.style.backgroundColor="antiquewhite"; 
        answe35.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error103() {
    var error1 = document.getElementById("no103");
    var error2 = document.getElementById("no104");
    var error3 = document.getElementById("no105");
    var answe35 = document.getElementById("iluminar");
    error1.style.backgroundColor="antiquewhite";
    answe35.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error104() {
    var error1 = document.getElementById("no103");
    var error2 = document.getElementById("no104");
    var error3 = document.getElementById("no105");
    var answe35 = document.getElementById("iluminar");
    error2.style.backgroundColor="antiquewhite";
    answe35.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error105() {
    var error1 = document.getElementById("no103");
    var error2 = document.getElementById("no104");
    var error3 = document.getElementById("no105");
    var answe35 = document.getElementById("iluminar");
    error3.style.backgroundColor="antiquewhite";
    answe35.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}



function pregunta36() {
    var error1 = document.getElementById("no106");
    var error2 = document.getElementById("no107");
    var error3 = document.getElementById("no108");
    var quest36 = document.getElementById("Poderoso");
    var answe36 = document.getElementById("magnete");
    if (quest36 = answe36) {
        answe36.style.backgroundColor="antiquewhite";  
        answe36.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true; 
    puntos++;
} else {}
}
function error106() {
    var error1 = document.getElementById("no106");
    var error2 = document.getElementById("no107");
    var error3 = document.getElementById("no108");
    var answe36 = document.getElementById("magnete");
    error1.style.backgroundColor="antiquewhite";
    answe36.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error107() {
    var error1 = document.getElementById("no106");
    var error2 = document.getElementById("no107");
    var error3 = document.getElementById("no108");
    var answe36 = document.getElementById("magnete");
    error2.style.backgroundColor="antiquewhite";
    answe36.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error108() {
    var error1 = document.getElementById("no106");
    var error2 = document.getElementById("no107");
    var error3 = document.getElementById("no108");
    var answe36 = document.getElementById("magnete");
    error3.style.backgroundColor="antiquewhite";
    answe36.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


    
function pregunta37() {
    var error1 = document.getElementById("no109");
    var error2 = document.getElementById("no110");
    var error3 = document.getElementById("no111");
    var quest37 = document.getElementById("Manuscribir");
    var answe37 = document.getElementById("transcribir");
    if (quest37 = answe37) {
        answe37.style.backgroundColor="antiquewhite";  
        answe37.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;
    puntos++;
} else {}
}
function error109() {
    var error1 = document.getElementById("no109");
    var error2 = document.getElementById("no110");
    var error3 = document.getElementById("no111");
    var answe37 = document.getElementById("transcribir");
    error1.style.backgroundColor="antiquewhite";
    answe37.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error110() {
    var error1 = document.getElementById("no109");
    var error2 = document.getElementById("no110");
    var error3 = document.getElementById("no111");
    var answe37 = document.getElementById("transcribir");
    error2.style.backgroundColor="antiquewhite";
    answe37.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error111() {
    var error1 = document.getElementById("no109");
    var error2 = document.getElementById("no110");
    var error3 = document.getElementById("no111");
    var answe37 = document.getElementById("transcribir");
    error3.style.backgroundColor="antiquewhite";
    answe37.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}


    
function pregunta38() {
    var error1 = document.getElementById("no112");
    var error2 = document.getElementById("no113");
    var error3 = document.getElementById("no114");
    var quest38 = document.getElementById("Lucha");
    var answe38 = document.getElementById("pelea");
    if (quest38 = answe38) {
        answe38.style.backgroundColor="antiquewhite"; 
        answe38.disabled=true;
        error1.disabled=true;
        error2.disabled=true;
        error3.disabled=true;  
    puntos++;
} else {}
}
function error112() {
    var error1 = document.getElementById("no112");
    var error2 = document.getElementById("no113");
    var error3 = document.getElementById("no114");
    var answe38 = document.getElementById("pelea");
    error1.style.backgroundColor="antiquewhite";
    answe38.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error113() {
    var error1 = document.getElementById("no112");
    var error2 = document.getElementById("no113");
    var error3 = document.getElementById("no114");
    var answe38 = document.getElementById("pelea");
    error2.style.backgroundColor="antiquewhite";
    answe38.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
function error114() {
    var error1 = document.getElementById("no112");
    var error2 = document.getElementById("no113");
    var error3 = document.getElementById("no114");
    var answe38 = document.getElementById("pelea");
    error3.style.backgroundColor="antiquewhite";
    answe38.disabled=true;
    error1.disabled=true;
    error2.disabled=true;
    error3.disabled=true;
}
console.log(puntos);